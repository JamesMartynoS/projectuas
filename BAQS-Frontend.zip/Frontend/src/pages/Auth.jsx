import { useState, useCallback } from 'react'
import { useNavigate } from 'react-router-dom'
import './Auth.css'

/* ── SVG Icons ── */
const ShieldIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
    <path d="M9 12l2 2 4-4"/>
  </svg>
)

const ChartIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <polyline points="22 12 18 12 15 21 9 3 6 12 2 12"/>
  </svg>
)

const UsersIcon = () => (
  <svg width="20" height="20" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17 21v-2a4 4 0 0 0-4-4H5a4 4 0 0 0-4 4v2"/>
    <circle cx="9" cy="7" r="4"/>
    <path d="M23 21v-2a4 4 0 0 0-3-3.87"/>
    <path d="M16 3.13a4 4 0 0 1 0 7.75"/>
  </svg>
)

const UserIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M20 21v-2a4 4 0 0 0-4-4H8a4 4 0 0 0-4 4v2"/>
    <circle cx="12" cy="7" r="4"/>
  </svg>
)

const LockIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <rect x="3" y="11" width="18" height="11" rx="2" ry="2"/>
    <path d="M7 11V7a5 5 0 0 1 10 0v4"/>
  </svg>
)

const MailIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M4 4h16c1.1 0 2 .9 2 2v12c0 1.1-.9 2-2 2H4c-1.1 0-2-.9-2-2V6c0-1.1.9-2 2-2z"/>
    <polyline points="22,6 12,13 2,6"/>
  </svg>
)

const EyeIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M1 12s4-8 11-8 11 8 11 8-4 8-11 8-11-8-11-8z"/>
    <circle cx="12" cy="12" r="3"/>
  </svg>
)

const EyeOffIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <path d="M17.94 17.94A10.07 10.07 0 0 1 12 20c-7 0-11-8-11-8a18.45 18.45 0 0 1 5.06-5.94M9.9 4.24A9.12 9.12 0 0 1 12 4c7 0 11 8 11 8a18.5 18.5 0 0 1-2.16 3.19m-6.72-1.07a3 3 0 1 1-4.24-4.24"/>
    <line x1="1" y1="1" x2="23" y2="23"/>
  </svg>
)

const ArrowLeftIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="19" y1="12" x2="5" y2="12"/>
    <polyline points="12 19 5 12 12 5"/>
  </svg>
)

const ArrowRightIcon = () => (
  <svg width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="currentColor" strokeWidth="2" strokeLinecap="round" strokeLinejoin="round">
    <line x1="5" y1="12" x2="19" y2="12"/>
    <polyline points="12 5 19 12 12 19"/>
  </svg>
)

/* ── BAQSLogo Component ── */
const BAQSLogo = ({ size = 'md' }) => {
  const sizes = {
    sm: { badge: '28px', text: '1rem' },
    md: { badge: '36px', text: '1.1rem' },
    lg: { badge: '44px', text: '1.4rem' },
  }
  const s = sizes[size]
  return (
    <div className="logo-badge" style={{ display: 'inline-flex', alignItems: 'center', gap: 10 }}>
      <div className="logo-icon" style={{ width: s.badge, height: s.badge }}>
        <svg viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.2" strokeLinecap="round" strokeLinejoin="round" style={{ width: '60%', height: '60%' }}>
          <path d="M12 22s8-4 8-10V5l-8-3-8 3v7c0 6 8 10 8 10z"/>
          <path d="M9 12l2 2 4-4"/>
        </svg>
      </div>
      <span style={{ fontFamily: 'Syne, sans-serif', fontWeight: 700, fontSize: s.text, color: 'white', letterSpacing: '0.04em' }}>
        BAQS
      </span>
    </div>
  )
}

/* ── Feature Card Component ── */
const FeatureCard = ({ icon, title, desc }) => (
  <div className="feature-card">
    <div className="icon-wrap" style={{ color: '#3b82f6' }}>
      {icon}
    </div>
    <div>
      <p style={{ fontFamily: 'Syne, sans-serif', fontWeight: 600, color: '#e2e8f0', fontSize: '0.9rem', marginBottom: 2 }}>
        {title}
      </p>
      <p style={{ color: '#64748b', fontSize: '0.8rem', lineHeight: 1.5 }}>
        {desc}
      </p>
    </div>
  </div>
)

/* ── Input Field Component ── */
const InputField = ({ label, icon, type = 'text', placeholder, value, onChange, showToggle, showPwd, onTogglePwd, name }) => (
  <div style={{ marginBottom: 16 }}>
    <label style={{
      display: 'block',
      marginBottom: 6,
      fontSize: '0.85rem',
      fontWeight: 500,
      color: '#94a3b8',
      fontFamily: 'DM Sans, sans-serif',
    }}>
      {label}
    </label>
    <div className="input-wrap">
      <span className="input-icon">{icon}</span>
      <input
        className="baqs-input"
        type={showToggle ? (showPwd ? 'text' : 'password') : type}
        placeholder={placeholder}
        value={value}
        onChange={onChange}
        name={name}
        autoComplete={type === 'password' ? 'current-password' : 'on'}
        style={{ paddingLeft: 42, paddingRight: showToggle ? 42 : 16 }}
      />
      {showToggle && (
        <button type="button" className="input-eye" onClick={onTogglePwd} tabIndex={-1}>
          {showPwd ? <EyeOffIcon /> : <EyeIcon />}
        </button>
      )}
    </div>
  </div>
)

/* ══════════════════════════════════════════
   LOGIN FORM
══════════════════════════════════════════ */
const LoginForm = ({ onSwitchToRegister }) => {
  const navigate = useNavigate()
  const [form, setForm] = useState({ username: '', password: '' })
  const [showPwd, setShowPwd] = useState(false)
  const [remember, setRemember] = useState(false)
  const [loading, setLoading] = useState(false)
  const [error, setError] = useState('')

  const handleChange = useCallback((e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
    setError('')
  }, [])

  const handleSubmit = async (e) => {
    e.preventDefault()
    if (!form.username.trim() || !form.password.trim()) {
      setError('Username dan password tidak boleh kosong.')
      return
    }
    setLoading(true)
    // Simulate API call
    await new Promise(r => setTimeout(r, 1200))
    setLoading(false)
    // Navigate to dashboard (replace with actual auth logic)
    navigate('/dashboard')
  }

  return (
    <div className="auth-card auth-card-scroll" style={{ padding: '40px 36px', width: '100%', maxWidth: 420 }}>
      <div style={{ textAlign: 'center', marginBottom: 32 }}>
        <h1 style={{
          fontFamily: 'Syne, sans-serif',
          fontWeight: 700,
          fontSize: '1.75rem',
          color: '#f1f5f9',
          marginBottom: 6,
        }}>
          Selamat Datang
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.875rem' }}>
          Masuk ke akun BAQS Anda
        </p>
      </div>

      {error && (
        <div style={{
          background: 'rgba(239,68,68,0.1)',
          border: '1px solid rgba(239,68,68,0.3)',
          borderRadius: 10,
          padding: '10px 14px',
          marginBottom: 16,
          color: '#fca5a5',
          fontSize: '0.82rem',
        }}>
          {error}
        </div>
      )}

      <form onSubmit={handleSubmit}>
        <InputField
          label="Username"
          icon={<UserIcon />}
          type="text"
          placeholder="Masukkan username"
          value={form.username}
          onChange={handleChange}
          name="username"
        />
        <InputField
          label="Password"
          icon={<LockIcon />}
          placeholder="Masukkan password"
          value={form.password}
          onChange={handleChange}
          name="password"
          showToggle
          showPwd={showPwd}
          onTogglePwd={() => setShowPwd(v => !v)}
        />

        <div style={{ display: 'flex', alignItems: 'center', justifyContent: 'space-between', marginBottom: 24 }}>
          <label style={{ display: 'flex', alignItems: 'center', gap: 8, cursor: 'pointer', userSelect: 'none' }}>
            <input
              type="checkbox"
              className="custom-checkbox"
              checked={remember}
              onChange={e => setRemember(e.target.checked)}
            />
            <span style={{ color: '#94a3b8', fontSize: '0.82rem' }}>Ingat saya</span>
          </label>
          <button
            type="button"
            style={{
              background: 'none',
              border: 'none',
              color: '#3b82f6',
              fontSize: '0.82rem',
              cursor: 'pointer',
              fontFamily: 'DM Sans, sans-serif',
            }}
            onMouseEnter={e => e.target.style.color = '#60a5fa'}
            onMouseLeave={e => e.target.style.color = '#3b82f6'}
          >
            Lupa password?
          </button>
        </div>

        <button type="submit" className="btn-shimmer baqs-btn-primary" disabled={loading}>
          {loading ? (
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <svg style={{ animation: 'spin 0.8s linear infinite' }} width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                <circle cx="12" cy="12" r="10" strokeOpacity="0.25"/>
                <path d="M12 2a10 10 0 0 1 10 10" strokeLinecap="round"/>
              </svg>
              Memproses...
            </span>
          ) : 'Login'}
        </button>

        <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
      </form>

      <p style={{ textAlign: 'center', marginTop: 24, color: '#64748b', fontSize: '0.85rem' }}>
        Belum punya akun?{' '}
        <button
          type="button"
          onClick={onSwitchToRegister}
          style={{
            background: 'none', border: 'none',
            color: '#3b82f6', fontWeight: 600,
            cursor: 'pointer', fontSize: '0.85rem',
            fontFamily: 'DM Sans, sans-serif',
          }}
          onMouseEnter={e => e.target.style.color = '#60a5fa'}
          onMouseLeave={e => e.target.style.color = '#3b82f6'}
        >
          Buat Akun
        </button>
      </p>
    </div>
  )
}

/* ══════════════════════════════════════════
   REGISTER FORM
══════════════════════════════════════════ */
const RegisterForm = ({ onSwitchToLogin }) => {
  const navigate = useNavigate()
  const [form, setForm] = useState({
    namaLengkap: '',
    username: '',
    email: '',
    password: '',
    konfirmasiPassword: '',
  })
  const [showPwd, setShowPwd] = useState(false)
  const [showPwd2, setShowPwd2] = useState(false)
  const [agree, setAgree] = useState(false)
  const [loading, setLoading] = useState(false)
  const [errors, setErrors] = useState({})

  const handleChange = useCallback((e) => {
    setForm(prev => ({ ...prev, [e.target.name]: e.target.value }))
    setErrors(prev => ({ ...prev, [e.target.name]: '' }))
  }, [])

  const validate = () => {
    const errs = {}
    if (!form.namaLengkap.trim()) errs.namaLengkap = 'Nama lengkap wajib diisi'
    if (!form.username.trim()) errs.username = 'Username wajib diisi'
    if (!form.email.includes('@')) errs.email = 'Email tidak valid'
    if (form.password.length < 8) errs.password = 'Password minimal 8 karakter'
    if (form.password !== form.konfirmasiPassword) errs.konfirmasiPassword = 'Password tidak cocok'
    if (!agree) errs.agree = 'Anda harus menyetujui syarat & ketentuan'
    return errs
  }

  const handleSubmit = async (e) => {
    e.preventDefault()
    const errs = validate()
    if (Object.keys(errs).length > 0) { setErrors(errs); return }
    setLoading(true)
    await new Promise(r => setTimeout(r, 1200))
    setLoading(false)
    navigate('/dashboard')
  }

  const FieldError = ({ field }) => errors[field] ? (
    <p style={{ color: '#f87171', fontSize: '0.75rem', marginTop: 4 }}>{errors[field]}</p>
  ) : null

  return (
    <div className="auth-card auth-card-scroll" style={{ padding: '36px 36px', width: '100%', maxWidth: 460 }}>
      {/* Back button */}
      <button
        type="button"
        onClick={onSwitchToLogin}
        style={{
          display: 'flex', alignItems: 'center', gap: 6,
          background: 'none', border: 'none',
          color: '#64748b', cursor: 'pointer',
          fontSize: '0.85rem', fontFamily: 'DM Sans, sans-serif',
          marginBottom: 24, padding: 0,
          transition: 'color 0.2s',
        }}
        onMouseEnter={e => e.currentTarget.style.color = '#94a3b8'}
        onMouseLeave={e => e.currentTarget.style.color = '#64748b'}
      >
        <ArrowLeftIcon />
        Kembali
      </button>

      <div style={{ marginBottom: 28 }}>
        <h1 style={{
          fontFamily: 'Syne, sans-serif',
          fontWeight: 700,
          fontSize: '1.6rem',
          color: '#f1f5f9',
          marginBottom: 6,
        }}>
          Buat Akun Baru
        </h1>
        <p style={{ color: '#64748b', fontSize: '0.85rem' }}>
          Bergabunglah dengan platform audit blockchain terpercaya
        </p>
      </div>

      <form onSubmit={handleSubmit}>
        {/* Nama Lengkap */}
        <div style={{ marginBottom: 4 }}>
          <InputField
            label="Nama Lengkap"
            icon={<UserIcon />}
            type="text"
            placeholder="Masukkan nama lengkap"
            value={form.namaLengkap}
            onChange={handleChange}
            name="namaLengkap"
          />
        </div>
        <FieldError field="namaLengkap" />

        {/* Username */}
        <div style={{ marginBottom: 4, marginTop: errors.namaLengkap ? 0 : 0 }}>
          <InputField
            label="Username"
            icon={<UserIcon />}
            type="text"
            placeholder="Pilih username unik"
            value={form.username}
            onChange={handleChange}
            name="username"
          />
        </div>
        <FieldError field="username" />

        {/* Email */}
        <div style={{ marginBottom: 4 }}>
          <InputField
            label="Email"
            icon={<MailIcon />}
            type="email"
            placeholder="nama@email.com"
            value={form.email}
            onChange={handleChange}
            name="email"
          />
        </div>
        <FieldError field="email" />

        {/* Password */}
        <div style={{ marginBottom: 4 }}>
          <InputField
            label="Password"
            icon={<LockIcon />}
            placeholder="Minimal 8 karakter"
            value={form.password}
            onChange={handleChange}
            name="password"
            showToggle
            showPwd={showPwd}
            onTogglePwd={() => setShowPwd(v => !v)}
          />
        </div>
        <FieldError field="password" />

        {/* Konfirmasi Password */}
        <div style={{ marginBottom: 4 }}>
          <InputField
            label="Konfirmasi Password"
            icon={<LockIcon />}
            placeholder="Ulangi password"
            value={form.konfirmasiPassword}
            onChange={handleChange}
            name="konfirmasiPassword"
            showToggle
            showPwd={showPwd2}
            onTogglePwd={() => setShowPwd2(v => !v)}
          />
        </div>
        <FieldError field="konfirmasiPassword" />

        {/* Terms */}
        <div style={{ marginTop: 16, marginBottom: 6 }}>
          <label style={{ display: 'flex', alignItems: 'flex-start', gap: 10, cursor: 'pointer', userSelect: 'none' }}>
            <input
              type="checkbox"
              className="custom-checkbox"
              style={{ marginTop: 2 }}
              checked={agree}
              onChange={e => { setAgree(e.target.checked); setErrors(prev => ({ ...prev, agree: '' })) }}
            />
            <span style={{ color: '#94a3b8', fontSize: '0.82rem', lineHeight: 1.6 }}>
              Saya setuju dengan{' '}
              <span style={{ color: '#3b82f6', cursor: 'pointer' }}>Syarat &amp; Ketentuan</span>
              {' '}dan{' '}
              <span style={{ color: '#3b82f6', cursor: 'pointer' }}>Kebijakan Privasi</span>
            </span>
          </label>
          {errors.agree && (
            <p style={{ color: '#f87171', fontSize: '0.75rem', marginTop: 4, marginLeft: 26 }}>{errors.agree}</p>
          )}
        </div>

        <button
          type="submit"
          className="btn-shimmer baqs-btn-primary"
          disabled={loading}
          style={{ marginTop: 20 }}
        >
          {loading ? (
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              <svg style={{ animation: 'spin 0.8s linear infinite' }} width="18" height="18" viewBox="0 0 24 24" fill="none" stroke="white" strokeWidth="2.5">
                <circle cx="12" cy="12" r="10" strokeOpacity="0.25"/>
                <path d="M12 2a10 10 0 0 1 10 10" strokeLinecap="round"/>
              </svg>
              Mendaftarkan...
            </span>
          ) : (
            <span style={{ display: 'flex', alignItems: 'center', justifyContent: 'center', gap: 8 }}>
              Daftar Sekarang
              <ArrowRightIcon />
            </span>
          )}
        </button>

        <style>{`@keyframes spin { from { transform: rotate(0deg); } to { transform: rotate(360deg); } }`}</style>
      </form>

      <p style={{ textAlign: 'center', marginTop: 20, color: '#64748b', fontSize: '0.85rem' }}>
        Sudah punya akun?{' '}
        <button
          type="button"
          onClick={onSwitchToLogin}
          style={{
            background: 'none', border: 'none',
            color: '#3b82f6', fontWeight: 600,
            cursor: 'pointer', fontSize: '0.85rem',
            fontFamily: 'DM Sans, sans-serif',
          }}
          onMouseEnter={e => e.target.style.color = '#60a5fa'}
          onMouseLeave={e => e.target.style.color = '#3b82f6'}
        >
          Masuk di sini
        </button>
      </p>
    </div>
  )
}

/* ══════════════════════════════════════════
   AUTH PAGE (Main Export)
══════════════════════════════════════════ */
export default function Auth({ mode = 'login' }) {
  const navigate = useNavigate()
  const isRegister = mode === 'register'

  const switchToRegister = () => navigate('/register')
  const switchToLogin = () => navigate('/login')

  const loginFeatures = [
    {
      icon: <ShieldIcon />,
      title: 'Keamanan Terjamin',
      desc: 'Enkripsi end-to-end dengan teknologi blockchain',
    },
    {
      icon: <ChartIcon />,
      title: 'Real-time Tracking',
      desc: 'Monitor audit secara langsung dan transparan',
    },
  ]

  const registerFeatures = [
    {
      icon: <ShieldIcon />,
      title: 'Keamanan Terjamin',
      desc: 'Audit blockchain dengan enkripsi tingkat enterprise',
    },
    {
      icon: <ChartIcon />,
      title: 'Real-time Analytics',
      desc: 'Monitor dan analisis transaksi secara langsung',
    },
    {
      icon: <UsersIcon />,
      title: 'Kolaborasi Tim',
      desc: 'Bekerja bersama tim audit dengan mudah',
    },
  ]

  const features = isRegister ? registerFeatures : loginFeatures

  return (
    <div
      className="auth-bg"
      style={{
        minHeight: '100vh',
        width: '100%',
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        padding: '24px 16px',
        position: 'relative',
      }}
    >
      {/* Decorative grid lines */}
      <div className="grid-lines" />

      {/* Floating orbs */}
      <div className="orb orb-1" />
      <div className="orb orb-2" />

      {/* Main layout */}
      <div style={{
        display: 'flex',
        alignItems: 'center',
        justifyContent: 'center',
        gap: 80,
        width: '100%',
        maxWidth: 1100,
        position: 'relative',
        zIndex: 1,
      }}>

        {/* LEFT PANEL */}
        <div
          className="auth-left"
          style={{
            flex: '0 0 auto',
            maxWidth: 480,
            display: 'none',
          }}
          ref={el => {
            if (el) el.style.display = 'block'
          }}
        >
          {/* Logo */}
          <div style={{ marginBottom: 32 }}>
            <BAQSLogo size={isRegister ? 'sm' : 'md'} />
            {isRegister && (
              <p style={{ color: '#475569', fontSize: '0.82rem', marginTop: 8, fontFamily: 'DM Sans, sans-serif' }}>
                Blockchain Audit &amp; Quality System
              </p>
            )}
          </div>

          {!isRegister && (
            <>
              <h2
                className="left-title"
                style={{
                  fontFamily: 'Syne, sans-serif',
                  fontWeight: 800,
                  fontSize: 'clamp(2rem, 4vw, 3rem)',
                  lineHeight: 1.15,
                  marginBottom: 16,
                  color: '#f1f5f9',
                }}
              >
                Blockchain
                <br />
                <span style={{ color: '#3b82f6' }}>Audit System</span>
              </h2>
              <p
                className="left-subtitle"
                style={{
                  color: '#64748b',
                  fontSize: '0.9rem',
                  lineHeight: 1.7,
                  marginBottom: 32,
                  maxWidth: 360,
                }}
              >
                Sistem audit blockchain yang aman dan terpercaya
                untuk merchant dan auditor profesional
              </p>
            </>
          )}

          {/* Feature cards */}
          <div style={{ display: 'flex', flexDirection: 'column', gap: 12 }}>
            {features.map((f, i) => (
              <FeatureCard key={i} {...f} />
            ))}
          </div>
        </div>

        {/* RIGHT PANEL */}
        <div style={{ flex: '0 0 auto' }}>
          {isRegister
            ? <RegisterForm onSwitchToLogin={switchToLogin} />
            : <LoginForm onSwitchToRegister={switchToRegister} />
          }
        </div>
      </div>

      {/* Responsive hide left on small screens */}
      <style>{`
        @media (max-width: 768px) {
          .auth-left { display: none !important; }
        }
        @media (min-width: 769px) {
          .auth-left { display: block !important; }
        }
      `}</style>
    </div>
  )
}
