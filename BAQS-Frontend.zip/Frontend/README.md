# BAQS — Blockchain Audit System Frontend

Frontend untuk sistem audit blockchain BAQS, dibangun dengan React + Vite + Tailwind CSS.

## Teknologi

- **React 18** — UI library
- **Vite** — Build tool & dev server
- **Tailwind CSS** — Utility-first CSS
- **React Router v6** — Client-side routing
- **Google Fonts** — Syne (display) + DM Sans (body)

## Struktur Project

```
Frontend/
├── public/
│   └── favicon.svg
├── src/
│   ├── assets/
│   ├── pages/
│   │   ├── Auth.jsx       ← Halaman login & register
│   │   └── Auth.css       ← Styles spesifik Auth
│   ├── App.jsx            ← Router root
│   ├── App.css
│   ├── main.jsx           ← Entry point
│   └── index.css          ← Global styles + Tailwind
├── index.html
├── package.json
├── tailwind.config.js
├── postcss.config.js
└── vite.config.js
```

## Cara Menjalankan

```bash
# Install dependencies
npm install

# Jalankan dev server
npm run dev

# Build untuk production
npm run build
```

## Routes

| Path | Halaman |
|------|---------|
| `/` | Redirect ke `/login` |
| `/login` | Halaman Login |
| `/register` | Halaman Register |
| `/dashboard` | Dashboard (placeholder) |

## Fitur Auth

### Login
- Form username + password
- Toggle show/hide password
- Checkbox "Ingat saya"
- Link "Lupa password"
- Validasi input
- Loading state

### Register
- Form nama lengkap, username, email, password, konfirmasi password
- Toggle show/hide password (dua field)
- Checkbox Syarat & Ketentuan
- Validasi per field
- Loading state
